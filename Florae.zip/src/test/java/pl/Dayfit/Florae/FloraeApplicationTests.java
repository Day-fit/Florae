package pl.Dayfit.Florae;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FloraeApplicationTests {

	@Test
	void contextLoads() {
	}

}
