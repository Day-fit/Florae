package pl.Dayfit.Florae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FloraeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FloraeApplication.class, args);
	}

}
